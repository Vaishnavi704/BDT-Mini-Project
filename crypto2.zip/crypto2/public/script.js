document.getElementById('connect-wallet').addEventListener('click', () => {
    // Mock connection without MetaMask
    const mockUserAddress = '0x1234567890abcdef1234567890abcdef12345678';
    document.getElementById('balance-info').innerText = `Connected as: ${mockUserAddress}`;
});

document.getElementById('send-transaction').addEventListener('click', async () => {
    const address = document.getElementById('address').value;
    const amount = document.getElementById('amount').value;

    if (address && amount) {
        try {
            const mockTransaction = {
                hash: '0x' + Math.random().toString(36).substring(2, 15),  // Random hash for mock transaction
                to: address,
                from: '0x1234567890abcdef1234567890abcdef12345678',
                value: amount,
                date: new Date().toISOString()
            };

            // Save the mock transaction to the backend
            await saveTransaction(mockTransaction);

            document.getElementById('transaction-status').innerText = `Mock transaction sent: ${mockTransaction.hash}`;
        } catch (error) {
            document.getElementById('transaction-status').innerText = `Error: ${error.message}`;
        }
    } else {
        alert('Please provide all details.');
    }
});

async function saveTransaction(tx) {
    // Send transaction details to the server to be saved in MongoDB
    await fetch('/save-transaction', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(tx)
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const generateWalletBtn = document.getElementById('generateWalletBtn');
    const walletInfo = document.getElementById('walletInfo');
    const walletAddress = document.getElementById('walletAddress');
    const publicKey = document.getElementById('publicKey');
    const errorDiv = document.getElementById('error');

    generateWalletBtn.addEventListener('click', async () => {
        // Disable the button to prevent multiple clicks
        generateWalletBtn.disabled = true;
        generateWalletBtn.textContent = 'Generating...';

        // Hide previous results or errors
        walletInfo.classList.add('hidden');
        errorDiv.classList.add('hidden');

        try {
            const response = await fetch('/generate-wallet', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                // If you need to send any data, include it here. For now, it's empty.
                body: JSON.stringify({})
            });

            if (!response.ok) {
                throw new Error(`Server error: ${response.statusText}`);
            }

            const data = await response.json();

            if (data.walletAddress && data.publicKey) {
                walletAddress.textContent = data.walletAddress;
                publicKey.textContent = data.publicKey;
                walletInfo.classList.remove('hidden');
            } else {
                throw new Error('Invalid response from server.');
            }
        } catch (error) {
            console.error('Error generating wallet:', error);
            errorDiv.textContent = `Error: ${error.message}`;
            errorDiv.classList.remove('hidden');
        } finally {
            // Re-enable the button
            generateWalletBtn.disabled = false;
            generateWalletBtn.textContent = 'Generate Wallet';
        }
    });
});
