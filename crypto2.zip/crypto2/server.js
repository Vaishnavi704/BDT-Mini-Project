const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());
app.use(cors());
app.use(express.static('public'));

// MongoDB connection
mongoose.connect('mongodb+srv://koastubh9dhayal:koastubh_9924@cluster1.ywmru.mongodb.net/transaction-wallet', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

// Transaction Schema
const transactionSchema = new mongoose.Schema({
    hash: String,
    to: String,
    from: String,
    value: String,
    date: { type: Date, default: Date.now }
});

const Transaction = mongoose.model('Transaction', transactionSchema);

// Wallet Schema
const walletSchema = new mongoose.Schema({
  address: { type: String, required: true },
  publicKey: { type: String, required: true },
  privateKey: { type: String, required: true }, // Encrypted private key
  dateCreated: { type: Date, default: Date.now }
});

const Wallet = mongoose.model('Wallet', walletSchema);
const WalletLib = require('ethereumjs-wallet').default;
const CryptoJS = require('crypto-js');
const generateWallet = () => {
  // Generate a new Ethereum wallet
  const ethWallet = WalletLib.generate();

  // Get the public and private keys
  const publicKey = ethWallet.getPublicKeyString();
  const privateKey = ethWallet.getPrivateKeyString();

  // Generate wallet address
  const address = ethWallet.getAddressString();

  // Encrypt the private key before saving it
  const encryptedPrivateKey = CryptoJS.AES.encrypt(privateKey, process.env.SECRET_KEY).toString();

  // Return wallet information
  return { address, publicKey, encryptedPrivateKey };
};
// API endpoint to generate and save a wallet
app.post('/generate-wallet', async (req, res) => {
  try {
      // Generate the wallet
      const { address, publicKey, encryptedPrivateKey } = generateWallet();

      // Create and save wallet document
      const newWallet = new Wallet({
          address,
          publicKey,
          privateKey: encryptedPrivateKey  // Store encrypted private key
      });

      await newWallet.save();

      // Respond with success and wallet address (NOT private key)
      res.status(201).json({
          message: 'Wallet generated successfully',
          walletAddress: address,
          publicKey: publicKey
      });
  } catch (error) {
      console.error('Error generating wallet:', error);
      res.status(500).json({ message: 'Error generating wallet', error: error.toString() });
  }
});

// Endpoint to save a mock transaction
app.post('/save-transaction', async (req, res) => {
    const { hash, to, from, value, date } = req.body;
    try {
        const newTransaction = new Transaction({ hash, to, from, value, date });
        await newTransaction.save();
        res.status(201).json({ message: 'Transaction saved', transaction: newTransaction });
    } catch (error) {
        res.status(400).json({ message: 'Error saving transaction', error });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
